#!/usr/bin/env bash
set -Eeuo pipefail
export AWS_PAGER=""

PROJECT_DIR="$HOME/opsai-assistant-aws"
WEB_DIR="$PROJECT_DIR/app/web"
ENV_FILE="$PROJECT_DIR/.env"

cd "$PROJECT_DIR"

if [[ ! -f "$ENV_FILE" ]]; then
  echo "ERROR: $ENV_FILE was not found."
  exit 1
fi

set -a
source "$ENV_FILE"
set +a

AWS_REGION="${AWS_REGION:-us-east-1}"
AMPLIFY_BRANCH_NAME="${AMPLIFY_BRANCH_NAME:-main}"

if [[ ! -f "$WEB_DIR/index.html" ]]; then
  echo "ERROR: $WEB_DIR/index.html was not found."
  exit 1
fi

if [[ ! -f "$WEB_DIR/hr-portal.js" ]]; then
  echo "ERROR: $WEB_DIR/hr-portal.js was not found."
  exit 1
fi

if [[ -z "${AMPLIFY_APP_ID:-}" ]]; then
  AMPLIFY_APP_ID="$(aws amplify list-apps \
    --region "$AWS_REGION" \
    --query "apps[?name=='opsai-assistant-ui'].appId | [0]" \
    --output text)"
fi

if [[ -z "$AMPLIFY_APP_ID" || "$AMPLIFY_APP_ID" == "None" ]]; then
  echo "ERROR: Unable to find the Amplify application."
  exit 1
fi

DEFAULT_DOMAIN="$(aws amplify get-app \
  --app-id "$AMPLIFY_APP_ID" \
  --region "$AWS_REGION" \
  --query 'app.defaultDomain' \
  --output text)"

AMPLIFY_URL="${AMPLIFY_URL:-https://${AMPLIFY_BRANCH_NAME}.${DEFAULT_DOMAIN}}"

BACKUP_TIME="$(date +%Y%m%d-%H%M%S)"
BACKUP_DIR="$PROJECT_DIR/backups/hr-quick-buttons-$BACKUP_TIME"
mkdir -p "$BACKUP_DIR"

cp "$WEB_DIR/index.html" "$BACKUP_DIR/index.html"

for file in opsai-hr-quick-buttons.js opsai-hr-quick-buttons.css; do
  if [[ -f "$WEB_DIR/$file" ]]; then
    cp "$WEB_DIR/$file" "$BACKUP_DIR/$file"
  fi
done

echo "Backup created: $BACKUP_DIR"

# ------------------------------------------------------------------
# Add styling for the small navigation notification.
# ------------------------------------------------------------------

cat > "$WEB_DIR/opsai-hr-quick-buttons.css" <<'CSSEOF'
/* OpsAI HR quick-button navigation */

.opsai-hr-navigation-toast {
  position: fixed;
  left: 50%;
  top: 84px;
  z-index: 10000;
  display: flex;
  align-items: center;
  gap: 9px;
  max-width: min(460px, calc(100vw - 32px));
  padding: 11px 15px;
  opacity: 0;
  visibility: hidden;
  transform: translate(-50%, -12px);
  border: 1px solid #bfdbfe;
  border-radius: 999px;
  background: rgba(255, 255, 255, .97);
  color: #1e3a8a;
  box-shadow: 0 15px 35px rgba(15, 39, 74, .16);
  backdrop-filter: blur(14px);
  font-size: 12px;
  font-weight: 800;
  transition:
    opacity .2s ease,
    visibility .2s ease,
    transform .2s ease;
}

.opsai-hr-navigation-toast.visible {
  opacity: 1;
  visibility: visible;
  transform: translate(-50%, 0);
}

.opsai-hr-navigation-toast.error {
  border-color: #fecaca;
  color: #991b1b;
  background: rgba(255, 241, 242, .98);
}

.opsai-hr-navigation-toast .opsai-toast-dot {
  width: 9px;
  height: 9px;
  flex: 0 0 auto;
  border-radius: 50%;
  background: #22c55e;
  box-shadow: 0 0 0 4px rgba(34, 197, 94, .12);
}

.opsai-hr-navigation-toast.error .opsai-toast-dot {
  background: #ef4444;
  box-shadow: 0 0 0 4px rgba(239, 68, 68, .12);
}
CSSEOF

# ------------------------------------------------------------------
# Intercept the two HR prompts and open the correct HR Portal view.
# ------------------------------------------------------------------

cat > "$WEB_DIR/opsai-hr-quick-buttons.js" <<'JSEOF'
(() => {
  const JOB_PROMPT =
    'show internal cloud and devops job openings';

  const CANDIDATE_PROMPT =
    'find devops candidates with around 10 years of experience';

  let toastTimer;

  function cleanText(value) {
    return String(value || '')
      .replace(/^[^\p{L}\p{N}]+/u, '')
      .replace(/\s+/g, ' ')
      .trim()
      .toLowerCase();
  }

  function waitFor(check, timeout = 6000, interval = 100) {
    return new Promise((resolve, reject) => {
      const started = Date.now();

      const timer = window.setInterval(() => {
        const result = check();

        if (result) {
          window.clearInterval(timer);
          resolve(result);
          return;
        }

        if (Date.now() - started >= timeout) {
          window.clearInterval(timer);
          reject(new Error('Timed out waiting for the HR Portal.'));
        }
      }, interval);
    });
  }

  function showToast(message, isError = false) {
    let toast = document.querySelector('.opsai-hr-navigation-toast');

    if (!toast) {
      toast = document.createElement('div');
      toast.className = 'opsai-hr-navigation-toast';
      toast.innerHTML = `
        <span class="opsai-toast-dot"></span>
        <span class="opsai-toast-message"></span>
      `;
      document.body.appendChild(toast);
    }

    toast.classList.toggle('error', isError);
    toast.querySelector('.opsai-toast-message').textContent = message;
    toast.classList.add('visible');

    window.clearTimeout(toastTimer);
    toastTimer = window.setTimeout(() => {
      toast.classList.remove('visible');
    }, isError ? 4200 : 2300);
  }

  function setNativeValue(element, value) {
    const prototype = element instanceof HTMLTextAreaElement
      ? HTMLTextAreaElement.prototype
      : element instanceof HTMLSelectElement
        ? HTMLSelectElement.prototype
        : HTMLInputElement.prototype;

    const descriptor =
      Object.getOwnPropertyDescriptor(prototype, 'value');

    if (descriptor?.set) {
      descriptor.set.call(element, value);
    } else {
      element.value = value;
    }

    element.dispatchEvent(new Event('input', { bubbles: true }));
    element.dispatchEvent(new Event('change', { bubbles: true }));
  }

  function findHRButton() {
    return (
      document.getElementById('hr-portal-nav-button') ||
      [...document.querySelectorAll('button, a')].find(item =>
        cleanText(item.textContent).includes('hr portal')
      )
    );
  }

  async function openHRPortal(role) {
    const hrButton = findHRButton();

    if (!hrButton) {
      throw new Error('The HR Portal button was not found.');
    }

    hrButton.click();

    const panel = await waitFor(() => {
      const candidate =
        document.getElementById('hr-portal-panel') ||
        document.querySelector('.hr-panel');

      if (!candidate) return null;

      const style = window.getComputedStyle(candidate);

      return (
        style.display !== 'none' &&
        style.visibility !== 'hidden' &&
        !candidate.classList.contains('demo-hidden')
      ) ? candidate : null;
    });

    const roleButton = await waitFor(() =>
      panel.querySelector(`[data-hr-role="${role}"]`)
    );

    roleButton.click();

    return waitFor(() => {
      const currentPanel =
        document.getElementById('hr-portal-panel') ||
        document.querySelector('.hr-panel');

      if (!currentPanel) return null;

      if (role === 'candidate') {
        return (
          currentPanel.querySelector('#candidate-job-keyword') ||
          currentPanel.querySelector('#hr-keyword')
        ) ? currentPanel : null;
      }

      return (
        currentPanel.querySelector('#manager-candidate-keyword') ||
        currentPanel.querySelector('#mgr-candidate-keyword')
      ) ? currentPanel : null;
    });
  }

  function scrollToSection(element) {
    const section =
      element.closest('.hr-section') ||
      element.closest('[class*="section"]') ||
      element;

    section.scrollIntoView({
      behavior: 'smooth',
      block: 'start'
    });

    element.focus({ preventScroll: true });
  }

  async function openDevOpsJobs() {
    showToast('Opening DevOps opportunities in the HR Portal...');

    const panel = await openHRPortal('candidate');

    const keyword =
      panel.querySelector('#candidate-job-keyword') ||
      panel.querySelector('#hr-keyword');

    if (!keyword) {
      throw new Error('The opportunity search field was not found.');
    }

    const city =
      panel.querySelector('#candidate-job-city') ||
      panel.querySelector('#hr-city');

    const experience =
      panel.querySelector('#candidate-job-experience') ||
      panel.querySelector('#hr-experience');

    const category =
      panel.querySelector('#candidate-job-category') ||
      panel.querySelector('#hr-category');

    setNativeValue(keyword, 'DevOps');

    if (city) setNativeValue(city, '');
    if (experience) setNativeValue(experience, '');
    if (category) setNativeValue(category, '');

    scrollToSection(keyword);

    showToast('DevOps job openings are ready.');
  }

  async function openDevOpsCandidates() {
    showToast('Opening the DevOps candidate search...');

    const panel = await openHRPortal('manager');

    const keyword =
      panel.querySelector('#manager-candidate-keyword') ||
      panel.querySelector('#mgr-candidate-keyword');

    if (!keyword) {
      throw new Error('The candidate search field was not found.');
    }

    const city =
      panel.querySelector('#manager-candidate-city') ||
      panel.querySelector('#mgr-candidate-city');

    const experience =
      panel.querySelector('#manager-candidate-experience') ||
      panel.querySelector('#mgr-candidate-experience');

    const status =
      panel.querySelector('#manager-candidate-status') ||
      panel.querySelector('#mgr-candidate-status');

    setNativeValue(keyword, 'DevOps');

    if (city) setNativeValue(city, '');

    if (experience) {
      const availableValues =
        [...experience.options].map(option => option.value);

      const range = availableValues.includes('6-10')
        ? '6-10'
        : availableValues.includes('10-15')
          ? '10-15'
          : '';

      setNativeValue(experience, range);
    }

    if (status) setNativeValue(status, '');

    scrollToSection(keyword);

    showToast('DevOps candidates with senior experience are ready.');
  }

  async function handlePrompt(event) {
    const button = event.target.closest('button');

    if (!button) return;

    const text = cleanText(button.textContent);

    const isJobPrompt =
      text.includes(JOB_PROMPT);

    const isCandidatePrompt =
      text.includes(CANDIDATE_PROMPT);

    if (!isJobPrompt && !isCandidatePrompt) return;

    /*
     * The old button behavior sends the prompt to Bedrock.
     * Stop that behavior and open the local HR Portal instead.
     */
    event.preventDefault();
    event.stopPropagation();
    event.stopImmediatePropagation();

    try {
      if (isJobPrompt) {
        await openDevOpsJobs();
      } else {
        await openDevOpsCandidates();
      }
    } catch (error) {
      console.error('OpsAI HR quick-button error:', error);
      showToast(
        error?.message || 'Unable to open the HR Portal search.',
        true
      );
    }
  }

  /*
   * Capture phase is required because the existing quick buttons have
   * their own click handlers that submit prompts to the chatbot.
   */
  document.addEventListener('click', handlePrompt, true);
})();
JSEOF

# ------------------------------------------------------------------
# Add versioned CSS and JavaScript references.
# ------------------------------------------------------------------

python3 - <<'PY'
from pathlib import Path
import re
import time

index_file = Path.home() / "opsai-assistant-aws" / "app" / "web" / "index.html"
content = index_file.read_text(encoding="utf-8")
version = str(int(time.time()))

content = re.sub(
    r'\s*<link[^>]+href=["\'][^"\']*opsai-hr-quick-buttons\.css[^"\']*["\'][^>]*>\s*',
    '\n',
    content,
    flags=re.IGNORECASE
)

content = re.sub(
    r'\s*<script[^>]+src=["\'][^"\']*opsai-hr-quick-buttons\.js[^"\']*["\'][^>]*>\s*</script>\s*',
    '\n',
    content,
    flags=re.IGNORECASE
)

css_tag = (
    f'  <link rel="stylesheet" '
    f'href="opsai-hr-quick-buttons.css?v={version}">'
)

js_tag = (
    f'  <script '
    f'src="opsai-hr-quick-buttons.js?v={version}"></script>'
)

if "</head>" not in content or "</body>" not in content:
    raise SystemExit(
        "ERROR: index.html is missing </head> or </body>."
    )

content = content.replace(
    "</head>",
    f"{css_tag}\n</head>",
    1
)

content = content.replace(
    "</body>",
    f"{js_tag}\n</body>",
    1
)

index_file.write_text(content, encoding="utf-8")

print(
    "HR quick-button references added "
    f"with version {version}."
)
PY

# ------------------------------------------------------------------
# Validate.
# ------------------------------------------------------------------

node --check "$WEB_DIR/opsai-hr-quick-buttons.js"

grep -q "openDevOpsJobs" \
  "$WEB_DIR/opsai-hr-quick-buttons.js"

grep -q "openDevOpsCandidates" \
  "$WEB_DIR/opsai-hr-quick-buttons.js"

grep -q "stopImmediatePropagation" \
  "$WEB_DIR/opsai-hr-quick-buttons.js"

grep -q "opsai-hr-quick-buttons.css" \
  "$WEB_DIR/index.html"

grep -q "opsai-hr-quick-buttons.js" \
  "$WEB_DIR/index.html"

echo "HR quick-button validation passed."

# ------------------------------------------------------------------
# Package and deploy.
# ------------------------------------------------------------------

rm -f "$PROJECT_DIR/app/opsai-assistant-ui.zip"

(
  cd "$WEB_DIR"
  zip -qr ../opsai-assistant-ui.zip .
)

DEPLOYMENT_OUTPUT="$(aws amplify create-deployment \
  --app-id "$AMPLIFY_APP_ID" \
  --branch-name "$AMPLIFY_BRANCH_NAME" \
  --region "$AWS_REGION" \
  --output json)"

JOB_ID="$(echo "$DEPLOYMENT_OUTPUT" | python3 -c \
  'import json,sys; print(json.load(sys.stdin)["jobId"])')"

UPLOAD_URL="$(echo "$DEPLOYMENT_OUTPUT" | python3 -c \
  'import json,sys; print(json.load(sys.stdin)["zipUploadUrl"])')"

echo "Amplify deployment job: $JOB_ID"

curl -sS \
  --upload-file "$PROJECT_DIR/app/opsai-assistant-ui.zip" \
  "$UPLOAD_URL"

aws amplify start-deployment \
  --app-id "$AMPLIFY_APP_ID" \
  --branch-name "$AMPLIFY_BRANCH_NAME" \
  --job-id "$JOB_ID" \
  --region "$AWS_REGION" \
  >/dev/null

while true; do
  STATUS="$(aws amplify get-job \
    --app-id "$AMPLIFY_APP_ID" \
    --branch-name "$AMPLIFY_BRANCH_NAME" \
    --job-id "$JOB_ID" \
    --region "$AWS_REGION" \
    --query 'job.summary.status' \
    --output text)"

  echo "Deployment status: $STATUS"

  case "$STATUS" in
    SUCCEED)
      break
      ;;
    FAILED|CANCELLED)
      echo "ERROR: Amplify deployment failed."
      exit 1
      ;;
    *)
      sleep 10
      ;;
  esac
done

echo
echo "========================================================"
echo "The two HR quick buttons were fixed successfully."
echo "========================================================"
echo
echo "Button 1:"
echo "  Opens HR Portal > Candidate View > DevOps jobs"
echo
echo "Button 2:"
echo "  Opens HR Portal > Manager View > DevOps candidates"
echo
echo "URL: $AMPLIFY_URL"
echo
echo "Open in Incognito or press Ctrl + Shift + R."
