#!/usr/bin/env bash
set -Eeuo pipefail
export AWS_PAGER=""

PROJECT_DIR="$HOME/opsai-assistant-aws"
WEB_DIR="$PROJECT_DIR/app/web"
ASSET_DIR="$WEB_DIR/assets"
ENV_FILE="$PROJECT_DIR/.env"

cd "$PROJECT_DIR"

if [[ ! -f "$ENV_FILE" ]]; then
  echo "ERROR: $ENV_FILE was not found."
  exit 1
fi

set -a
source "$ENV_FILE"
set +a

AWS_REGION="${AWS_REGION:-us-east-1}"
AMPLIFY_BRANCH_NAME="${AMPLIFY_BRANCH_NAME:-main}"

if [[ ! -f "$WEB_DIR/index.html" ]]; then
  echo "ERROR: $WEB_DIR/index.html was not found."
  exit 1
fi

if [[ -z "${AMPLIFY_APP_ID:-}" ]]; then
  AMPLIFY_APP_ID="$(aws amplify list-apps \
    --region "$AWS_REGION" \
    --query "apps[?name=='opsai-assistant-ui'].appId | [0]" \
    --output text)"
fi

if [[ -z "$AMPLIFY_APP_ID" || "$AMPLIFY_APP_ID" == "None" ]]; then
  echo "ERROR: Unable to find the Amplify app ID."
  exit 1
fi

DEFAULT_DOMAIN="$(aws amplify get-app \
  --app-id "$AMPLIFY_APP_ID" \
  --region "$AWS_REGION" \
  --query 'app.defaultDomain' \
  --output text)"

AMPLIFY_URL="${AMPLIFY_URL:-https://${AMPLIFY_BRANCH_NAME}.${DEFAULT_DOMAIN}}"

BACKUP_TIME="$(date +%Y%m%d-%H%M%S)"
BACKUP_DIR="$PROJECT_DIR/backups/final-ui-$BACKUP_TIME"
mkdir -p "$BACKUP_DIR" "$ASSET_DIR"

cp "$WEB_DIR/index.html" "$BACKUP_DIR/index.html"

for file in styles.css app.js demo-ops.css demo-ops.js hr-portal.css hr-portal.js; do
  if [[ -f "$WEB_DIR/$file" ]]; then
    cp "$WEB_DIR/$file" "$BACKUP_DIR/$file"
  fi
done

echo "Backup created: $BACKUP_DIR"

# ================================================================
# 1. Create all local SVG image assets.
# ================================================================

cat > "$ASSET_DIR/opsai-robot.svg" <<'SVGEOF'
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 520 420" role="img" aria-labelledby="title desc">
  <title id="title">OpsAI robot assistant</title>
  <desc id="desc">Friendly blue AI robot with a chat bubble</desc>
  <defs>
    <linearGradient id="bg" x1="0" x2="1" y1="0" y2="1">
      <stop offset="0" stop-color="#eff6ff"/>
      <stop offset="1" stop-color="#dbeafe"/>
    </linearGradient>
    <linearGradient id="body" x1="0" x2="1">
      <stop offset="0" stop-color="#2563eb"/>
      <stop offset="1" stop-color="#7c3aed"/>
    </linearGradient>
    <filter id="shadow" x="-30%" y="-30%" width="160%" height="160%">
      <feDropShadow dx="0" dy="18" stdDeviation="18" flood-color="#1e3a8a" flood-opacity=".18"/>
    </filter>
  </defs>
  <rect x="18" y="18" width="484" height="384" rx="48" fill="url(#bg)"/>
  <circle cx="92" cy="78" r="12" fill="#60a5fa" opacity=".55"/>
  <circle cx="450" cy="96" r="18" fill="#a78bfa" opacity=".45"/>
  <circle cx="418" cy="334" r="9" fill="#38bdf8" opacity=".55"/>
  <path d="M83 293c-16-58 19-133 88-158 66-23 145 9 178 68 33 59 13 139-41 178-57 41-144 29-194-21-19-19-27-42-31-67z" fill="#ffffff" opacity=".72"/>
  <g filter="url(#shadow)">
    <rect x="143" y="118" width="235" height="196" rx="56" fill="url(#body)"/>
    <rect x="164" y="142" width="193" height="114" rx="36" fill="#0f172a"/>
    <circle cx="219" cy="198" r="18" fill="#7dd3fc"/>
    <circle cx="303" cy="198" r="18" fill="#c4b5fd"/>
    <circle cx="219" cy="198" r="7" fill="#ffffff"/>
    <circle cx="303" cy="198" r="7" fill="#ffffff"/>
    <path d="M224 232c22 18 50 18 74 0" fill="none" stroke="#e0f2fe" stroke-width="9" stroke-linecap="round"/>
    <rect x="236" y="84" width="49" height="43" rx="20" fill="#2563eb"/>
    <path d="M260 84V56" stroke="#2563eb" stroke-width="10" stroke-linecap="round"/>
    <circle cx="260" cy="47" r="14" fill="#38bdf8"/>
    <rect x="106" y="187" width="48" height="72" rx="22" fill="#3b82f6"/>
    <rect x="367" y="187" width="48" height="72" rx="22" fill="#7c3aed"/>
    <rect x="190" y="294" width="43" height="66" rx="20" fill="#1d4ed8"/>
    <rect x="290" y="294" width="43" height="66" rx="20" fill="#6d28d9"/>
    <circle cx="261" cy="284" r="10" fill="#ffffff" opacity=".9"/>
  </g>
  <g transform="translate(340 58)">
    <path d="M0 0h128a25 25 0 0 1 25 25v52a25 25 0 0 1-25 25H52L25 124l5-22H0A25 25 0 0 1-25 77V25A25 25 0 0 1 0 0z" fill="#ffffff" stroke="#bfdbfe" stroke-width="4"/>
    <circle cx="30" cy="51" r="8" fill="#2563eb"/>
    <circle cx="64" cy="51" r="8" fill="#60a5fa"/>
    <circle cx="98" cy="51" r="8" fill="#8b5cf6"/>
  </g>
</svg>
SVGEOF

cat > "$ASSET_DIR/opsai-ai-orb.svg" <<'SVGEOF'
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 500 500" role="img" aria-label="AI network orb">
  <defs>
    <radialGradient id="orb" cx="45%" cy="38%">
      <stop offset="0" stop-color="#ffffff"/>
      <stop offset=".28" stop-color="#93c5fd"/>
      <stop offset=".68" stop-color="#6366f1"/>
      <stop offset="1" stop-color="#312e81"/>
    </radialGradient>
    <filter id="glow">
      <feGaussianBlur stdDeviation="8" result="b"/>
      <feMerge><feMergeNode in="b"/><feMergeNode in="SourceGraphic"/></feMerge>
    </filter>
  </defs>
  <circle cx="250" cy="250" r="198" fill="url(#orb)" opacity=".95"/>
  <g stroke="#dbeafe" stroke-width="4" opacity=".65">
    <path d="M95 230L190 132l117 44 96 117-134 95-126-45z"/>
    <path d="M190 132l79 256M95 230l308 63M143 343l164-167"/>
    <path d="M190 132L403 293M95 230l174 158"/>
  </g>
  <g fill="#ffffff" filter="url(#glow)">
    <circle cx="95" cy="230" r="12"/>
    <circle cx="190" cy="132" r="15"/>
    <circle cx="307" cy="176" r="11"/>
    <circle cx="403" cy="293" r="16"/>
    <circle cx="269" cy="388" r="13"/>
    <circle cx="143" cy="343" r="11"/>
    <circle cx="250" cy="250" r="22"/>
  </g>
</svg>
SVGEOF

cat > "$ASSET_DIR/opsai-infrastructure.svg" <<'SVGEOF'
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 520 360" role="img" aria-label="Cloud infrastructure illustration">
  <defs>
    <linearGradient id="g" x1="0" x2="1">
      <stop offset="0" stop-color="#0ea5e9"/>
      <stop offset="1" stop-color="#2563eb"/>
    </linearGradient>
  </defs>
  <rect width="520" height="360" rx="42" fill="#eff6ff"/>
  <path d="M338 70c47 0 85 27 94 67 34 2 61 30 61 65 0 37-30 67-67 67H281c-41 0-74-33-74-74 0-36 26-66 61-73 14-31 39-52 70-52z" fill="url(#g)" opacity=".92"/>
  <g fill="#ffffff">
    <rect x="55" y="70" width="150" height="232" rx="20"/>
    <rect x="75" y="92" width="110" height="52" rx="10" fill="#dbeafe"/>
    <rect x="75" y="158" width="110" height="52" rx="10" fill="#bfdbfe"/>
    <rect x="75" y="224" width="110" height="52" rx="10" fill="#93c5fd"/>
    <circle cx="95" cy="118" r="7" fill="#22c55e"/>
    <circle cx="95" cy="184" r="7" fill="#f59e0b"/>
    <circle cx="95" cy="250" r="7" fill="#ef4444"/>
    <rect x="112" y="111" width="55" height="12" rx="6" fill="#2563eb"/>
    <rect x="112" y="177" width="55" height="12" rx="6" fill="#2563eb"/>
    <rect x="112" y="243" width="55" height="12" rx="6" fill="#2563eb"/>
  </g>
  <path d="M220 207h65M253 174v66" stroke="#2563eb" stroke-width="10" stroke-linecap="round"/>
  <circle cx="253" cy="207" r="34" fill="#ffffff" stroke="#bfdbfe" stroke-width="6"/>
  <path d="M242 207l9 9 18-22" fill="none" stroke="#16a34a" stroke-width="8" stroke-linecap="round" stroke-linejoin="round"/>
</svg>
SVGEOF

cat > "$ASSET_DIR/opsai-hr-team.svg" <<'SVGEOF'
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 520 360" role="img" aria-label="Internal HR team illustration">
  <defs>
    <linearGradient id="bg" x1="0" x2="1">
      <stop offset="0" stop-color="#ede9fe"/>
      <stop offset="1" stop-color="#dbeafe"/>
    </linearGradient>
  </defs>
  <rect width="520" height="360" rx="42" fill="url(#bg)"/>
  <rect x="65" y="64" width="390" height="242" rx="28" fill="#ffffff"/>
  <rect x="90" y="88" width="340" height="34" rx="12" fill="#eff6ff"/>
  <circle cx="112" cy="105" r="8" fill="#2563eb"/>
  <circle cx="137" cy="105" r="8" fill="#8b5cf6"/>
  <circle cx="162" cy="105" r="8" fill="#14b8a6"/>
  <g>
    <circle cx="160" cy="183" r="34" fill="#60a5fa"/>
    <path d="M102 270c8-44 30-66 58-66s50 22 58 66" fill="#2563eb"/>
    <circle cx="260" cy="170" r="40" fill="#c4b5fd"/>
    <path d="M191 270c9-52 35-78 69-78s60 26 69 78" fill="#7c3aed"/>
    <circle cx="360" cy="183" r="34" fill="#5eead4"/>
    <path d="M302 270c8-44 30-66 58-66s50 22 58 66" fill="#0f766e"/>
  </g>
  <rect x="213" y="282" width="94" height="12" rx="6" fill="#dbeafe"/>
</svg>
SVGEOF

cat > "$ASSET_DIR/opsai-approvals.svg" <<'SVGEOF'
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 520 360" role="img" aria-label="Human approval workflow illustration">
  <defs>
    <linearGradient id="shield" x1="0" x2="1">
      <stop offset="0" stop-color="#2563eb"/>
      <stop offset="1" stop-color="#14b8a6"/>
    </linearGradient>
  </defs>
  <rect width="520" height="360" rx="42" fill="#ecfeff"/>
  <path d="M260 45l145 53v96c0 72-50 124-145 154-95-30-145-82-145-154V98z" fill="url(#shield)"/>
  <path d="M196 193l42 43 91-101" fill="none" stroke="#ffffff" stroke-width="22" stroke-linecap="round" stroke-linejoin="round"/>
  <rect x="55" y="100" width="105" height="40" rx="12" fill="#ffffff" stroke="#bae6fd" stroke-width="4"/>
  <rect x="360" y="231" width="105" height="40" rx="12" fill="#ffffff" stroke="#99f6e4" stroke-width="4"/>
  <circle cx="78" cy="120" r="8" fill="#f59e0b"/>
  <circle cx="383" cy="251" r="8" fill="#22c55e"/>
</svg>
SVGEOF

# ================================================================
# 2. Create final visual theme stylesheet.
# ================================================================

cat > "$WEB_DIR/opsai-theme-final.css" <<'CSSEOF'
:root {
  --opsai-blue: #2563eb;
  --opsai-indigo: #4f46e5;
  --opsai-violet: #7c3aed;
  --opsai-cyan: #06b6d4;
  --opsai-navy: #0f274a;
  --opsai-ink: #0f172a;
  --opsai-muted: #64748b;
  --opsai-panel: rgba(255, 255, 255, .90);
  --opsai-border: rgba(148, 163, 184, .28);
  --opsai-shadow: 0 24px 70px rgba(15, 39, 74, .12);
}

html {
  scroll-behavior: smooth;
}

body {
  background:
    radial-gradient(circle at 70% 12%, rgba(99, 102, 241, .11), transparent 28%),
    radial-gradient(circle at 28% 85%, rgba(6, 182, 212, .10), transparent 25%),
    #f4f7fc !important;
  color: var(--opsai-ink);
}

body::before {
  content: "";
  position: fixed;
  inset: 0;
  pointer-events: none;
  background-image:
    linear-gradient(rgba(37, 99, 235, .025) 1px, transparent 1px),
    linear-gradient(90deg, rgba(37, 99, 235, .025) 1px, transparent 1px);
  background-size: 38px 38px;
  mask-image: linear-gradient(to bottom, rgba(0,0,0,.55), transparent 85%);
  z-index: 0;
}

#sidebar {
  background:
    linear-gradient(180deg, #0d2a55 0%, #132f5c 48%, #0b2348 100%) !important;
  box-shadow: 14px 0 40px rgba(15, 39, 74, .12);
  border-right: 1px solid rgba(255,255,255,.08);
}

#sidebar::before {
  content: "";
  position: absolute;
  inset: 0;
  pointer-events: none;
  background:
    radial-gradient(circle at 15% 8%, rgba(96, 165, 250, .20), transparent 22%),
    radial-gradient(circle at 90% 70%, rgba(124, 58, 237, .14), transparent 24%);
}

#sidebar > * {
  position: relative;
  z-index: 1;
}

#new-chat-button,
.demo-nav-button,
#hr-portal-nav-button {
  border: 1px solid rgba(255,255,255,.16) !important;
  background: rgba(255,255,255,.055) !important;
  color: #f8fafc !important;
  border-radius: 12px !important;
  transition: transform .18s ease, background .18s ease, box-shadow .18s ease !important;
}

#new-chat-button:hover,
.demo-nav-button:hover,
#hr-portal-nav-button:hover {
  transform: translateX(3px);
  background: rgba(255,255,255,.12) !important;
}

.demo-nav-button.active,
#hr-portal-nav-button.active {
  background: linear-gradient(135deg, #2563eb, #7c3aed) !important;
  border-color: rgba(255,255,255,.30) !important;
  box-shadow: 0 10px 24px rgba(37, 99, 235, .28);
}

.top-header {
  background: rgba(255,255,255,.82) !important;
  backdrop-filter: blur(18px);
  border-bottom: 1px solid var(--opsai-border) !important;
  box-shadow: 0 8px 28px rgba(15,23,42,.045);
}

.top-header h2 {
  color: var(--opsai-ink) !important;
  letter-spacing: -.02em;
}

.opsai-header-badge {
  display: inline-flex;
  align-items: center;
  gap: 7px;
  margin-left: 10px;
  padding: 6px 11px;
  border-radius: 999px;
  color: #1d4ed8;
  background: #eff6ff;
  border: 1px solid #bfdbfe;
  font-size: 11px;
  font-weight: 800;
  vertical-align: middle;
}

.chat-area,
main {
  position: relative;
  z-index: 1;
}

.opsai-welcome-card {
  position: relative !important;
  overflow: hidden !important;
  max-width: 820px !important;
  padding: 28px 34px 30px !important;
  border: 1px solid rgba(191, 219, 254, .75) !important;
  border-radius: 28px !important;
  background:
    linear-gradient(145deg, rgba(255,255,255,.96), rgba(248,250,252,.88)) !important;
  box-shadow: var(--opsai-shadow) !important;
  backdrop-filter: blur(20px);
}

.opsai-welcome-card::before {
  content: "";
  position: absolute;
  width: 280px;
  height: 280px;
  right: -120px;
  top: -140px;
  border-radius: 50%;
  background: radial-gradient(circle, rgba(124,58,237,.18), transparent 68%);
}

.opsai-welcome-card::after {
  content: "";
  position: absolute;
  width: 260px;
  height: 260px;
  left: -120px;
  bottom: -155px;
  border-radius: 50%;
  background: radial-gradient(circle, rgba(6,182,212,.17), transparent 68%);
}

.opsai-hero-visual {
  position: relative;
  z-index: 2;
  display: grid;
  place-items: center;
  margin: -8px auto 8px;
}

.opsai-hero-visual img {
  width: min(290px, 58vw);
  height: auto;
  filter: drop-shadow(0 24px 35px rgba(37,99,235,.16));
  animation: opsaiFloat 5s ease-in-out infinite;
}

@keyframes opsaiFloat {
  0%, 100% { transform: translateY(0); }
  50% { transform: translateY(-9px); }
}

.opsai-welcome-card h1,
.opsai-welcome-card h2,
.opsai-welcome-card h3 {
  position: relative;
  z-index: 2;
  margin-top: 2px !important;
  color: var(--opsai-ink) !important;
  font-size: clamp(26px, 3.1vw, 40px) !important;
  line-height: 1.12 !important;
  letter-spacing: -.035em;
}

.opsai-welcome-card p {
  position: relative;
  z-index: 2;
  color: var(--opsai-muted) !important;
  font-size: 14px !important;
}

.opsai-quick-prompt {
  position: relative;
  z-index: 2;
  border: 1px solid #dbeafe !important;
  background: linear-gradient(135deg, #ffffff, #f8fbff) !important;
  border-radius: 13px !important;
  box-shadow: 0 8px 18px rgba(15,23,42,.04);
  transition: transform .18s ease, border-color .18s ease, box-shadow .18s ease;
}

.opsai-quick-prompt:hover {
  transform: translateY(-2px);
  border-color: #93c5fd !important;
  box-shadow: 0 14px 25px rgba(37,99,235,.10);
}

.composer-area,
[class*="composer"] {
  background: rgba(255,255,255,.78);
  backdrop-filter: blur(16px);
}

.composer-area input,
.composer-area textarea,
[class*="composer"] input,
[class*="composer"] textarea {
  border-radius: 16px !important;
  border: 1px solid #93c5fd !important;
  box-shadow: 0 10px 28px rgba(37,99,235,.08);
}

.composer-area button,
[class*="composer"] button {
  border-radius: 12px !important;
  background: linear-gradient(135deg, #2563eb, #4f46e5) !important;
  box-shadow: 0 8px 18px rgba(37,99,235,.20);
}

.message,
[class*="message-bubble"],
[data-role="assistant"],
[data-role="user"] {
  border-radius: 18px !important;
}

.opsai-module-hero {
  display: grid;
  grid-template-columns: minmax(0, 1fr) 220px;
  align-items: center;
  gap: 22px;
  margin: 0 0 18px;
  padding: 20px 24px;
  overflow: hidden;
  border: 1px solid #dbeafe;
  border-radius: 22px;
  background:
    linear-gradient(135deg, rgba(255,255,255,.96), rgba(239,246,255,.90));
  box-shadow: 0 16px 40px rgba(15,39,74,.08);
}

.opsai-module-hero h2 {
  margin: 0 0 7px !important;
  font-size: 28px !important;
  color: var(--opsai-ink) !important;
}

.opsai-module-hero p {
  margin: 0 !important;
  color: var(--opsai-muted) !important;
  line-height: 1.5;
}

.opsai-module-hero img {
  width: 100%;
  max-height: 150px;
  object-fit: contain;
  filter: drop-shadow(0 15px 22px rgba(37,99,235,.13));
}

.demo-panel,
.hr-panel {
  position: relative;
}

.demo-node-card,
.hr-section,
.hr-job-card,
.hr-manager-card,
.hr-profile-card,
.demo-summary-card,
[class*="approval-card"] {
  border-radius: 16px !important;
  border-color: rgba(148,163,184,.30) !important;
  box-shadow: 0 12px 30px rgba(15,23,42,.055);
  transition: transform .18s ease, box-shadow .18s ease;
}

.demo-node-card:hover,
.hr-job-card:hover,
.hr-manager-card:hover,
.hr-profile-card:hover,
[class*="approval-card"]:hover {
  transform: translateY(-2px);
  box-shadow: 0 18px 38px rgba(15,23,42,.085);
}

.hr-summary-card,
.demo-summary-card {
  position: relative;
  overflow: hidden;
}

.hr-summary-card::after,
.demo-summary-card::after {
  content: "";
  position: absolute;
  right: -18px;
  top: -18px;
  width: 58px;
  height: 58px;
  border-radius: 50%;
  background: rgba(37,99,235,.07);
}

.hr-primary-button,
.demo-action-button,
button[class*="primary"] {
  background: linear-gradient(135deg, #2563eb, #4f46e5) !important;
  border: 0 !important;
  box-shadow: 0 8px 18px rgba(37,99,235,.16);
}

.hr-role-button.active {
  background: linear-gradient(135deg, #2563eb, #7c3aed) !important;
}

.hr-status,
.demo-status {
  box-shadow: inset 0 0 0 1px rgba(255,255,255,.55);
}

.opsai-ai-orb {
  position: fixed;
  right: 3vw;
  bottom: 10vh;
  width: 115px;
  opacity: .10;
  pointer-events: none;
  z-index: 0;
  animation: opsaiSpin 30s linear infinite;
}

@keyframes opsaiSpin {
  to { transform: rotate(360deg); }
}

@media (max-width: 800px) {
  .opsai-module-hero {
    grid-template-columns: 1fr;
  }

  .opsai-module-hero img {
    max-height: 125px;
  }

  .opsai-welcome-card {
    margin: 14px !important;
    padding: 22px 18px !important;
  }

  .opsai-ai-orb {
    display: none;
  }
}
CSSEOF

# ================================================================
# 3. Create final visual behavior script.
# ================================================================

cat > "$WEB_DIR/opsai-theme-final.js" <<'JSEOF'
(() => {
  const ICONS = {
    newChat: '💬',
    infrastructure: '🖥️',
    approvals: '✅',
    hr: '👥'
  };

  function cleanText(value) {
    return String(value || '')
      .replace(/^[\s\u{1F300}-\u{1FAFF}\u2600-\u27BF▣▦✓✔+]+/gu, '')
      .trim();
  }

  function setButtonLabel(button, icon, label) {
    if (!button) return;
    const current = cleanText(button.textContent);
    if (current.toLowerCase().includes(label.toLowerCase())) {
      button.textContent = `${icon} ${label}`;
    }
  }

  function applySidebarIcons() {
    const newChat = document.getElementById('new-chat-button');
    if (newChat) newChat.textContent = `${ICONS.newChat} New Chat`;

    document.querySelectorAll('button, a').forEach(element => {
      const text = cleanText(element.textContent).toLowerCase();

      if (text.includes('infrastructure assets')) {
        element.textContent = `${ICONS.infrastructure} Infrastructure Assets`;
      } else if (text === 'approvals' || text.includes('approvals')) {
        const badge = element.querySelector('.demo-count-badge, .badge');
        const badgeText = badge ? badge.textContent : '';
        element.textContent = `${ICONS.approvals} Approvals`;
        if (badge && badgeText) {
          badge.textContent = badgeText;
          element.appendChild(badge);
        }
      } else if (text.includes('hr portal')) {
        element.textContent = `${ICONS.hr} HR Portal`;
      } else if (text === 'candidate view') {
        element.textContent = '👩‍💻 Candidate View';
      } else if (text === 'manager view') {
        element.textContent = '👨‍💼 Manager View';
      }
    });
  }

  function findWelcomeCard() {
    const headings = [...document.querySelectorAll('h1,h2,h3')];
    const heading = headings.find(item =>
      /hello,\s*i am opsai assistant/i.test(item.textContent || '')
    );

    if (!heading) return null;

    let node = heading.parentElement;

    while (node && node !== document.body) {
      const rect = node.getBoundingClientRect();
      const text = node.textContent || '';

      if (
        text.includes('Hello, I am OpsAI Assistant') &&
        text.length < 900 &&
        rect.width > 280
      ) {
        return node;
      }

      node = node.parentElement;
    }

    return heading.parentElement;
  }

  function improveWelcomeCard() {
    const card = findWelcomeCard();
    if (!card) return;

    card.classList.add('opsai-welcome-card');

    if (!card.querySelector('.opsai-hero-visual')) {
      const hero = document.createElement('div');
      hero.className = 'opsai-hero-visual';
      hero.innerHTML = `
        <img
          src="assets/opsai-robot.svg"
          alt="Friendly OpsAI robot assistant"
        >
      `;

      const heading = [...card.querySelectorAll('h1,h2,h3')].find(item =>
        /hello,\s*i am opsai assistant/i.test(item.textContent || '')
      );

      if (heading) card.insertBefore(hero, heading);
      else card.prepend(hero);
    }

    const subtitle = [...card.querySelectorAll('p')].find(item =>
      /kubernetes|rke2|jenkins|cloud|infrastructure/i.test(item.textContent || '')
    );

    if (subtitle) {
      subtitle.textContent =
        'Your intelligent assistant for Kubernetes, RKE2, Jenkins, cloud, infrastructure and internal opportunities.';
    }

    card.querySelectorAll('button').forEach(button => {
      button.classList.add('opsai-quick-prompt');
      const text = cleanText(button.textContent);

      if (/node|kubernetes/i.test(text)) button.textContent = `☸️ ${text}`;
      else if (/diskpressure|disk/i.test(text)) button.textContent = `💾 ${text}`;
      else if (/jenkins|pipeline/i.test(text)) button.textContent = `🚀 ${text}`;
      else if (/job|career|hr/i.test(text)) button.textContent = `👥 ${text}`;
    });
  }

  function addHeaderBadge() {
    const heading = document.querySelector('.top-header h2');
    if (!heading || heading.querySelector('.opsai-header-badge')) return;

    const badge = document.createElement('span');
    badge.className = 'opsai-header-badge';
    badge.textContent = '✨ AI-powered operations';
    heading.appendChild(badge);
  }

  function addAmbientOrb() {
    if (document.querySelector('.opsai-ai-orb')) return;

    const orb = document.createElement('img');
    orb.className = 'opsai-ai-orb';
    orb.src = 'assets/opsai-ai-orb.svg';
    orb.alt = '';
    orb.setAttribute('aria-hidden', 'true');
    document.body.appendChild(orb);
  }

  function moduleConfig(title) {
    const text = title.toLowerCase();

    if (text.includes('infrastructure')) {
      return {
        image: 'assets/opsai-infrastructure.svg',
        eyebrow: '🖥️ Infrastructure Operations',
        description:
          'Monitor health, patching, vulnerabilities, reboots and approval-based remediation.'
      };
    }

    if (text.includes('internal hr portal') || text === 'hr portal') {
      return {
        image: 'assets/opsai-hr-team.svg',
        eyebrow: '👥 Internal Talent Marketplace',
        description:
          'Search opportunities, discover internal candidates and manage every hiring stage.'
      };
    }

    if (text.includes('approval')) {
      return {
        image: 'assets/opsai-approvals.svg',
        eyebrow: '✅ Human Approval Workflow',
        description:
          'Review, approve, reject and validate controlled operational actions.'
      };
    }

    return null;
  }

  function addModuleHeroes() {
    const panels = document.querySelectorAll('.demo-panel, .hr-panel');

    panels.forEach(panel => {
      if (panel.classList.contains('demo-hidden')) return;
      if (panel.querySelector(':scope > .opsai-module-hero')) return;

      const heading = panel.querySelector('h1,h2,h3');
      if (!heading) return;

      const config = moduleConfig(cleanText(heading.textContent));
      if (!config) return;

      const hero = document.createElement('div');
      hero.className = 'opsai-module-hero';
      hero.innerHTML = `
        <div>
          <div class="opsai-header-badge">${config.eyebrow}</div>
          <h2>${cleanText(heading.textContent)}</h2>
          <p>${config.description}</p>
        </div>
        <img src="${config.image}" alt="">
      `;

      panel.prepend(hero);
    });
  }

  function improveSectionHeadings() {
    document.querySelectorAll('.hr-section h3, .demo-panel h2, .demo-panel h3')
      .forEach(heading => {
        const text = cleanText(heading.textContent);

        if (/current opportunities|open requisitions/i.test(text)) {
          heading.textContent = `💼 ${text}`;
        } else if (/candidate pool|candidate applications/i.test(text)) {
          heading.textContent = `🧑‍💻 ${text}`;
        } else if (/hiring managers|projects/i.test(text)) {
          heading.textContent = `👨‍💼 ${text}`;
        } else if (/application/i.test(text)) {
          heading.textContent = `📄 ${text}`;
        } else if (/worker|asset|infrastructure/i.test(text)) {
          heading.textContent = `🖥️ ${text}`;
        } else if (/approval/i.test(text)) {
          heading.textContent = `✅ ${text}`;
        }
      });
  }

  function addAssistantAvatars() {
    const selectors = [
      '[data-role="assistant"]',
      '.assistant-message',
      '.message.assistant',
      '[class*="assistant-message"]'
    ];

    document.querySelectorAll(selectors.join(',')).forEach(message => {
      if (message.querySelector('.opsai-message-avatar')) return;

      const avatar = document.createElement('img');
      avatar.className = 'opsai-message-avatar';
      avatar.src = 'assets/opsai-robot.svg';
      avatar.alt = 'OpsAI';
      avatar.style.cssText =
        'width:34px;height:34px;object-fit:cover;border-radius:50%;margin-right:8px;vertical-align:top;';
      message.prepend(avatar);
    });
  }

  function applyAll() {
    applySidebarIcons();
    improveWelcomeCard();
    addHeaderBadge();
    addAmbientOrb();
    addModuleHeroes();
    improveSectionHeadings();
    addAssistantAvatars();
  }

  let queued = false;

  function queueApply() {
    if (queued) return;
    queued = true;

    requestAnimationFrame(() => {
      queued = false;
      applyAll();
    });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', applyAll);
  } else {
    applyAll();
  }

  const observer = new MutationObserver(queueApply);
  observer.observe(document.documentElement, {
    childList: true,
    subtree: true
  });

  window.addEventListener('load', applyAll);
})();
JSEOF

# ================================================================
# 4. Update index.html references with cache-busting.
# ================================================================

python3 - <<'PY'
from pathlib import Path
import re
import time

index_file = Path.home() / "opsai-assistant-aws" / "app" / "web" / "index.html"
content = index_file.read_text(encoding="utf-8")
version = str(int(time.time()))

content = re.sub(
    r'\s*<link[^>]+href=["\'][^"\']*opsai-theme-final\.css[^"\']*["\'][^>]*>\s*',
    '\n',
    content,
    flags=re.IGNORECASE
)

content = re.sub(
    r'\s*<script[^>]+src=["\'][^"\']*opsai-theme-final\.js[^"\']*["\'][^>]*>\s*</script>\s*',
    '\n',
    content,
    flags=re.IGNORECASE
)

css_tag = f'  <link rel="stylesheet" href="opsai-theme-final.css?v={version}">'
js_tag = f'  <script src="opsai-theme-final.js?v={version}"></script>'

if "</head>" not in content or "</body>" not in content:
    raise SystemExit("ERROR: index.html is missing </head> or </body>.")

content = content.replace("</head>", f"{css_tag}\n</head>", 1)
content = content.replace("</body>", f"{js_tag}\n</body>", 1)

index_file.write_text(content, encoding="utf-8")
print(f"Final visual theme references added with version {version}.")
PY

# ================================================================
# 5. Validate all created files.
# ================================================================

node --check "$WEB_DIR/opsai-theme-final.js"

for file in \
  "$ASSET_DIR/opsai-robot.svg" \
  "$ASSET_DIR/opsai-ai-orb.svg" \
  "$ASSET_DIR/opsai-infrastructure.svg" \
  "$ASSET_DIR/opsai-hr-team.svg" \
  "$ASSET_DIR/opsai-approvals.svg" \
  "$WEB_DIR/opsai-theme-final.css" \
  "$WEB_DIR/opsai-theme-final.js"
do
  if [[ ! -s "$file" ]]; then
    echo "ERROR: Missing or empty file: $file"
    exit 1
  fi
done

grep -q "opsai-theme-final.css" "$WEB_DIR/index.html"
grep -q "opsai-theme-final.js" "$WEB_DIR/index.html"
grep -q "opsai-robot.svg" "$WEB_DIR/opsai-theme-final.js"
grep -q "opsai-infrastructure.svg" "$WEB_DIR/opsai-theme-final.js"
grep -q "opsai-hr-team.svg" "$WEB_DIR/opsai-theme-final.js"
grep -q "opsai-approvals.svg" "$WEB_DIR/opsai-theme-final.js"

echo "Final UI validation passed."
echo "Created 5 local SVG images."
echo "Created the final theme CSS and JavaScript."

# ================================================================
# 6. Package and deploy to Amplify.
# ================================================================

rm -f "$PROJECT_DIR/app/opsai-assistant-ui.zip"

(
  cd "$WEB_DIR"
  zip -qr ../opsai-assistant-ui.zip .
)

DEPLOYMENT_OUTPUT="$(aws amplify create-deployment \
  --app-id "$AMPLIFY_APP_ID" \
  --branch-name "$AMPLIFY_BRANCH_NAME" \
  --region "$AWS_REGION" \
  --output json)"

JOB_ID="$(echo "$DEPLOYMENT_OUTPUT" | python3 -c \
  'import json,sys; print(json.load(sys.stdin)["jobId"])')"

UPLOAD_URL="$(echo "$DEPLOYMENT_OUTPUT" | python3 -c \
  'import json,sys; print(json.load(sys.stdin)["zipUploadUrl"])')"

echo "Amplify deployment job: $JOB_ID"

curl -sS \
  --upload-file "$PROJECT_DIR/app/opsai-assistant-ui.zip" \
  "$UPLOAD_URL"

aws amplify start-deployment \
  --app-id "$AMPLIFY_APP_ID" \
  --branch-name "$AMPLIFY_BRANCH_NAME" \
  --job-id "$JOB_ID" \
  --region "$AWS_REGION" \
  >/dev/null

while true; do
  STATUS="$(aws amplify get-job \
    --app-id "$AMPLIFY_APP_ID" \
    --branch-name "$AMPLIFY_BRANCH_NAME" \
    --job-id "$JOB_ID" \
    --region "$AWS_REGION" \
    --query 'job.summary.status' \
    --output text)"

  echo "Deployment status: $STATUS"

  case "$STATUS" in
    SUCCEED)
      break
      ;;
    FAILED|CANCELLED)
      echo "ERROR: Amplify deployment failed."
      exit 1
      ;;
    *)
      sleep 10
      ;;
  esac
done

echo
echo "========================================================"
echo "Final OpsAI visual UI deployed successfully."
echo "========================================================"
echo
echo "URL: $AMPLIFY_URL"
echo
echo "Open the URL in an Incognito window or press Ctrl + Shift + R."
