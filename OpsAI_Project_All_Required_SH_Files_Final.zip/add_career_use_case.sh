#!/usr/bin/env bash
set -euo pipefail
export AWS_PAGER=""

cd "$HOME/opsai-assistant-aws"

if [[ ! -f .env ]]; then
  echo "ERROR: .env was not found in $HOME/opsai-assistant-aws"
  exit 1
fi

set -a
source .env
set +a

SOURCE_FILE="$HOME/cgi-career-opportunities-demo.md"

if [[ ! -f "$SOURCE_FILE" ]]; then
  echo "ERROR: Upload cgi-career-opportunities-demo.md to CloudShell first."
  exit 1
fi

cp "$SOURCE_FILE" data/cgi-career-opportunities-demo.md

aws s3 cp   data/cgi-career-opportunities-demo.md   "s3://$OPSAI_BUCKET/knowledge/cgi-career-opportunities-demo.md"

KB_ID=$(aws bedrock-agent list-knowledge-bases   --region "$AWS_REGION"   --query "knowledgeBaseSummaries[?name=='opsai-assistant-kb'].knowledgeBaseId | [0]"   --output text)

DATA_SOURCE_ID=$(aws bedrock-agent list-data-sources   --knowledge-base-id "$KB_ID"   --region "$AWS_REGION"   --query "dataSourceSummaries[?name=='opsai-runbooks-s3'].dataSourceId | [0]"   --output text)

echo "Knowledge Base ID: $KB_ID"
echo "Data Source ID: $DATA_SOURCE_ID"

JOB_ID=$(aws bedrock-agent start-ingestion-job   --knowledge-base-id "$KB_ID"   --data-source-id "$DATA_SOURCE_ID"   --description "Add career opportunities demo use case"   --region "$AWS_REGION"   --query 'ingestionJob.ingestionJobId'   --output text)

echo "Ingestion Job ID: $JOB_ID"

while true; do
  STATUS=$(aws bedrock-agent get-ingestion-job     --knowledge-base-id "$KB_ID"     --data-source-id "$DATA_SOURCE_ID"     --ingestion-job-id "$JOB_ID"     --region "$AWS_REGION"     --query 'ingestionJob.status'     --output text)

  echo "Sync status: $STATUS"

  case "$STATUS" in
    COMPLETE)
      break
      ;;
    FAILED|STOPPED)
      echo "Knowledge Base sync failed."
      aws bedrock-agent get-ingestion-job         --knowledge-base-id "$KB_ID"         --data-source-id "$DATA_SOURCE_ID"         --ingestion-job-id "$JOB_ID"         --region "$AWS_REGION"         --query 'ingestionJob.failureReasons'         --output json
      exit 1
      ;;
    *)
      sleep 10
      ;;
  esac
done

echo
echo "Career opportunities demo data was added successfully."
echo
echo "Test question:"
echo "I am looking for a Cloud Engineer with around 4 years of experience in Hyderabad. What matches are available?"
