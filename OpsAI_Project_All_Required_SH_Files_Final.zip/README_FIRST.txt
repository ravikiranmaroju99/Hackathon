OPSAI ASSISTANT AWS PROJECT — FINAL SHELL SCRIPT SET
======================================================

Use this file set only. Older repair and intermediate scripts are intentionally
excluded to avoid confusion.

FRESH BUILD ORDER
-----------------
Steps 1–19:
Follow the complete Notepad guide because those steps create AWS resources,
the Knowledge Base, Bedrock Agent, Lambda, API Gateway, Amplify, and the base UI.

Step 20:
Run:
  add_opsai_demo_tabs.sh

This adds Infrastructure Assets and Approvals to the already-deployed base UI.

Step 22 — RECOMMENDED FINAL INSTALLATION:
Run only:
  step22_to_hr_quick_buttons_all_in_one_final.sh

This all-in-one script already contains and runs the final HR Portal and UI
phases. Do not run the component scripts again after it succeeds.

FINAL COMPONENT SCRIPTS
-----------------------
These are provided separately for troubleshooting or rerunning one phase:

  install_opsai_hr_portal_final.sh
  upgrade_opsai_ui_with_images_final.sh
  fix_opsai_ui_moving_data.sh
  upgrade_opsai_home_enhancements_final.sh
  replace_map_with_right_side_globe.sh
  fix_opsai_hr_quick_buttons_final.sh

Run these component scripts only when you need to repair or update that
specific phase. When using the all-in-one Step 22 file, they are not required
to be run separately.

OPTIONAL KNOWLEDGE BASE CAREER DATA
-----------------------------------
  add_career_use_case.sh

This is optional. It requires the separate source file:
  cgi-career-opportunities-demo.md

It uploads that document to the Knowledge Base and starts a sync. The final HR
quick buttons do not depend on this script because they open the local HR Portal
directly.

COMPLETE CLEANUP
----------------
Run only when you want to remove the AWS project resources:

  cleanup_opsai_aws.sh

IMPORTANT
---------
1. All scripts expect the project folder:
     $HOME/opsai-assistant-aws

2. Most scripts expect:
     $HOME/opsai-assistant-aws/.env

3. Use the same AWS IAM identity and us-east-1 region used for the build.

4. Do not run obsolete scripts such as:
     add_opsai_hr_portal.sh
     upgrade_opsai_hr_portal_v2.sh
     upgrade_opsai_hr_hiring_stages.sh
     repair_hr_portal_tab.sh
     fix_opsai_hr_portal_missing_tab.sh
     add_opsai_world_map_final.sh

5. After any Amplify deployment, open the website in Incognito mode or press:
     Ctrl + Shift + R
