#!/usr/bin/env bash
set -Eeuo pipefail
export AWS_PAGER=""

PROJECT_DIR="$HOME/opsai-assistant-aws"
WEB_DIR="$PROJECT_DIR/app/web"
ENV_FILE="$PROJECT_DIR/.env"

cd "$PROJECT_DIR"

if [[ ! -f "$ENV_FILE" ]]; then
  echo "ERROR: $ENV_FILE was not found."
  exit 1
fi

set -a
source "$ENV_FILE"
set +a

AWS_REGION="${AWS_REGION:-us-east-1}"
AMPLIFY_BRANCH_NAME="${AMPLIFY_BRANCH_NAME:-main}"

if [[ -z "${AMPLIFY_APP_ID:-}" ]]; then
  AMPLIFY_APP_ID="$(aws amplify list-apps \
    --region "$AWS_REGION" \
    --query "apps[?name=='opsai-assistant-ui'].appId | [0]" \
    --output text)"
fi

if [[ -z "$AMPLIFY_APP_ID" || "$AMPLIFY_APP_ID" == "None" ]]; then
  echo "ERROR: Unable to find the Amplify application."
  exit 1
fi

DEFAULT_DOMAIN="$(aws amplify get-app \
  --app-id "$AMPLIFY_APP_ID" \
  --region "$AWS_REGION" \
  --query 'app.defaultDomain' \
  --output text)"

AMPLIFY_URL="${AMPLIFY_URL:-https://${AMPLIFY_BRANCH_NAME}.${DEFAULT_DOMAIN}}"

for required in \
  index.html \
  opsai-theme-final.css \
  opsai-theme-final.js \
  assets/opsai-robot.svg \
  assets/opsai-infrastructure.svg \
  assets/opsai-hr-team.svg \
  assets/opsai-approvals.svg
do
  if [[ ! -s "$WEB_DIR/$required" ]]; then
    echo "ERROR: Missing required file: $WEB_DIR/$required"
    exit 1
  fi
done

BACKUP_TIME="$(date +%Y%m%d-%H%M%S)"
BACKUP_DIR="$PROJECT_DIR/backups/ui-enhancements-$BACKUP_TIME"
mkdir -p "$BACKUP_DIR"

cp "$WEB_DIR/index.html" "$BACKUP_DIR/index.html"

for file in opsai-ui-enhancements.css opsai-ui-enhancements.js; do
  if [[ -f "$WEB_DIR/$file" ]]; then
    cp "$WEB_DIR/$file" "$BACKUP_DIR/$file"
  fi
done

echo "Backup created: $BACKUP_DIR"

cat > "$WEB_DIR/opsai-ui-enhancements.css" <<'CSSEOF'
/* OpsAI final home-screen enhancements */

.opsai-welcome-card {
  width: min(980px, calc(100vw - 360px)) !important;
  max-width: 980px !important;
  padding: 28px 34px 30px !important;
}

.opsai-extra-prompts {
  position: relative;
  z-index: 2;
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  gap: 9px;
  margin-top: 9px;
}

.opsai-extra-prompts .opsai-quick-prompt {
  min-height: 46px !important;
  margin: 0 !important;
}

.opsai-feature-grid {
  position: relative;
  z-index: 2;
  display: grid;
  grid-template-columns: repeat(3, minmax(0, 1fr));
  gap: 12px;
  margin-top: 18px;
}

.opsai-feature-card {
  position: relative;
  display: grid;
  grid-template-columns: 70px minmax(0, 1fr);
  align-items: center;
  gap: 12px;
  min-height: 108px;
  padding: 14px;
  overflow: hidden;
  border: 1px solid rgba(147, 197, 253, .58);
  border-radius: 17px;
  background:
    linear-gradient(145deg, rgba(255,255,255,.96), rgba(239,246,255,.78));
  box-shadow: 0 12px 27px rgba(15,39,74,.065);
  cursor: pointer;
  text-align: left;
  transition:
    transform .18s ease,
    box-shadow .18s ease,
    border-color .18s ease;
}

.opsai-feature-card:hover {
  transform: translateY(-3px);
  border-color: #60a5fa;
  box-shadow: 0 18px 34px rgba(37,99,235,.12);
}

.opsai-feature-card::after {
  content: "";
  position: absolute;
  right: -25px;
  bottom: -30px;
  width: 90px;
  height: 90px;
  border-radius: 50%;
  background: rgba(99,102,241,.07);
}

.opsai-feature-card img {
  width: 70px;
  height: 70px;
  object-fit: contain;
  filter: drop-shadow(0 9px 12px rgba(37,99,235,.11));
}

.opsai-feature-card strong {
  display: block;
  margin-bottom: 5px;
  color: #0f172a;
  font-size: 13px;
}

.opsai-feature-card span {
  display: block;
  color: #64748b;
  font-size: 11px;
  line-height: 1.4;
}

.opsai-status-strip {
  position: relative;
  z-index: 2;
  display: grid;
  grid-template-columns: repeat(4, minmax(0, 1fr));
  gap: 8px;
  margin-top: 13px;
}

.opsai-status-item {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 7px;
  min-height: 35px;
  padding: 7px 9px;
  border: 1px solid #dbeafe;
  border-radius: 999px;
  background: rgba(248,250,252,.88);
  color: #475569;
  font-size: 10px;
  font-weight: 700;
  white-space: nowrap;
}

.opsai-status-dot {
  width: 8px;
  height: 8px;
  flex: 0 0 auto;
  border-radius: 50%;
  background: #22c55e;
  box-shadow: 0 0 0 4px rgba(34,197,94,.12);
}

.opsai-thinking-indicator {
  position: absolute;
  left: 50%;
  bottom: 82px;
  z-index: 30;
  display: none;
  align-items: center;
  gap: 10px;
  transform: translateX(-50%);
  padding: 10px 15px;
  border: 1px solid #bfdbfe;
  border-radius: 999px;
  background: rgba(255,255,255,.96);
  color: #334155;
  box-shadow: 0 12px 30px rgba(15,39,74,.12);
  backdrop-filter: blur(14px);
  font-size: 12px;
  font-weight: 700;
}

.opsai-thinking-indicator.visible {
  display: flex;
}

.opsai-thinking-indicator img {
  width: 28px;
  height: 28px;
  border-radius: 50%;
  object-fit: cover;
}

.opsai-thinking-dots {
  display: inline-flex;
  gap: 4px;
}

.opsai-thinking-dots i {
  width: 5px;
  height: 5px;
  border-radius: 50%;
  background: #2563eb;
  animation: opsaiThinking 1.1s ease-in-out infinite;
}

.opsai-thinking-dots i:nth-child(2) {
  animation-delay: .14s;
}

.opsai-thinking-dots i:nth-child(3) {
  animation-delay: .28s;
}

@keyframes opsaiThinking {
  0%, 60%, 100% {
    transform: translateY(0);
    opacity: .38;
  }
  30% {
    transform: translateY(-4px);
    opacity: 1;
  }
}

@media (max-width: 1050px) {
  .opsai-welcome-card {
    width: min(880px, calc(100vw - 250px)) !important;
  }

  .opsai-feature-grid {
    grid-template-columns: 1fr;
  }

  .opsai-feature-card {
    min-height: 90px;
  }
}

@media (max-width: 760px) {
  .opsai-welcome-card {
    width: auto !important;
  }

  .opsai-extra-prompts,
  .opsai-status-strip {
    grid-template-columns: 1fr;
  }

  .opsai-status-item {
    justify-content: flex-start;
    padding-left: 14px;
  }
}

@media (prefers-reduced-motion: reduce) {
  .opsai-thinking-dots i {
    animation: none;
  }
}
CSSEOF

cat > "$WEB_DIR/opsai-ui-enhancements.js" <<'JSEOF'
(() => {
  let observer;
  let queued = false;
  let thinkingTimer;

  function cleanText(value) {
    return String(value || '')
      .replace(/^[^\p{L}\p{N}]+/u, '')
      .replace(/\s+/g, ' ')
      .trim();
  }

  function findWelcomeCard() {
    const heading = [...document.querySelectorAll('h1,h2,h3')].find(item =>
      /hello,\s*i am opsai assistant/i.test(item.textContent || '')
    );

    if (!heading) return null;

    let node = heading.parentElement;

    while (node && node !== document.body) {
      const text = node.textContent || '';

      if (
        text.includes('Hello, I am OpsAI Assistant') &&
        text.length < 1800
      ) {
        return node;
      }

      node = node.parentElement;
    }

    return heading.parentElement;
  }

  function clickNavigation(label) {
    const target = [...document.querySelectorAll('button, a')].find(item =>
      cleanText(item.textContent).toLowerCase().includes(label.toLowerCase())
    );

    if (target) target.click();
  }

  function setNativeValue(element, value) {
    const prototype = element instanceof HTMLTextAreaElement
      ? HTMLTextAreaElement.prototype
      : HTMLInputElement.prototype;

    const descriptor = Object.getOwnPropertyDescriptor(prototype, 'value');

    if (descriptor?.set) descriptor.set.call(element, value);
    else element.value = value;

    element.dispatchEvent(new Event('input', { bubbles: true }));
    element.dispatchEvent(new Event('change', { bubbles: true }));
  }

  function submitPrompt(text) {
    const composer = document.querySelector('.composer-area') ||
      document.querySelector('[class*="composer"]');

    if (!composer) return;

    const input = composer.querySelector('textarea, input[type="text"], input:not([type])');
    const button = composer.querySelector('button');

    if (!input || !button) return;

    setNativeValue(input, text);
    input.focus();

    window.setTimeout(() => {
      showThinking();
      button.click();
    }, 80);
  }

  function createExtraPrompts(card) {
    if (card.querySelector('.opsai-extra-prompts')) return;

    const container = document.createElement('div');
    container.className = 'opsai-extra-prompts';

    const prompts = [
      {
        icon: '💼',
        text: 'Show internal cloud and DevOps job openings'
      },
      {
        icon: '👨‍💻',
        text: 'Find DevOps candidates with around 10 years of experience'
      }
    ];

    prompts.forEach(prompt => {
      const button = document.createElement('button');
      button.type = 'button';
      button.className = 'opsai-quick-prompt';
      button.textContent = `${prompt.icon} ${prompt.text}`;
      button.addEventListener('click', () => submitPrompt(prompt.text));
      container.appendChild(button);
    });

    const warning = [...card.querySelectorAll('div,p,small')].find(item =>
      /human approval|production changes|reboots and deletions/i.test(
        item.textContent || ''
      )
    );

    if (warning?.parentElement === card) {
      card.insertBefore(container, warning);
    } else {
      card.appendChild(container);
    }
  }

  function createFeatureCards(card) {
    if (card.querySelector('.opsai-feature-grid')) return;

    const grid = document.createElement('div');
    grid.className = 'opsai-feature-grid';

    const features = [
      {
        title: 'Infrastructure Assistant',
        description: 'Health, patching, vulnerabilities and remediation approvals.',
        image: 'assets/opsai-infrastructure.svg',
        navigation: 'Infrastructure Assets'
      },
      {
        title: 'HR Talent Assistant',
        description: 'Internal jobs, candidates, managers and hiring stages.',
        image: 'assets/opsai-hr-team.svg',
        navigation: 'HR Portal'
      },
      {
        title: 'Approval Assistant',
        description: 'Review and approve controlled operational actions.',
        image: 'assets/opsai-approvals.svg',
        navigation: 'Approvals'
      }
    ];

    features.forEach(feature => {
      const button = document.createElement('button');
      button.type = 'button';
      button.className = 'opsai-feature-card';
      button.innerHTML = `
        <img src="${feature.image}" alt="">
        <span>
          <strong>${feature.title}</strong>
          <span>${feature.description}</span>
        </span>
      `;

      button.addEventListener('click', () =>
        clickNavigation(feature.navigation)
      );

      grid.appendChild(button);
    });

    const warning = [...card.querySelectorAll('div,p,small')].find(item =>
      /human approval|production changes|reboots and deletions/i.test(
        item.textContent || ''
      )
    );

    if (warning?.parentElement === card) {
      card.insertBefore(grid, warning);
    } else {
      card.appendChild(grid);
    }
  }

  function createStatusStrip(card) {
    if (card.querySelector('.opsai-status-strip')) return;

    const strip = document.createElement('div');
    strip.className = 'opsai-status-strip';

    const statuses = [
      'OpsAI Online',
      'Knowledge Base Connected',
      'AWS Bedrock Ready',
      'Human Approval Enabled'
    ];

    statuses.forEach(status => {
      const item = document.createElement('div');
      item.className = 'opsai-status-item';
      item.innerHTML = `
        <span class="opsai-status-dot"></span>
        <span>${status}</span>
      `;
      strip.appendChild(item);
    });

    const warning = [...card.querySelectorAll('div,p,small')].find(item =>
      /human approval|production changes|reboots and deletions/i.test(
        item.textContent || ''
      )
    );

    if (warning?.parentElement === card) {
      card.insertBefore(strip, warning);
    } else {
      card.appendChild(strip);
    }
  }

  function createThinkingIndicator() {
    if (document.querySelector('.opsai-thinking-indicator')) return;

    const chatArea = document.querySelector('.chat-area') ||
      document.querySelector('main');

    const composer = document.querySelector('.composer-area') ||
      document.querySelector('[class*="composer"]');

    if (!chatArea || !composer) return;

    const indicator = document.createElement('div');
    indicator.className = 'opsai-thinking-indicator';
    indicator.innerHTML = `
      <img src="assets/opsai-robot.svg" alt="">
      <span>OpsAI is thinking</span>
      <span class="opsai-thinking-dots">
        <i></i><i></i><i></i>
      </span>
    `;

    chatArea.insertBefore(indicator, composer);
  }

  function showThinking() {
    createThinkingIndicator();

    const indicator = document.querySelector('.opsai-thinking-indicator');
    if (!indicator) return;

    indicator.classList.add('visible');

    window.clearTimeout(thinkingTimer);
    thinkingTimer = window.setTimeout(() => {
      indicator.classList.remove('visible');
    }, 2400);
  }

  function attachComposerEvents() {
    const composer = document.querySelector('.composer-area') ||
      document.querySelector('[class*="composer"]');

    if (!composer || composer.dataset.opsaiThinkingBound === '1') return;

    composer.dataset.opsaiThinkingBound = '1';

    composer.addEventListener('click', event => {
      if (event.target.closest('button')) showThinking();
    }, true);

    composer.addEventListener('keydown', event => {
      if (
        event.key === 'Enter' &&
        !event.shiftKey &&
        event.target.matches('textarea, input')
      ) {
        showThinking();
      }
    }, true);
  }

  function ensureConsistentIcons() {
    const mappings = [
      ['new chat', '💬 New Chat'],
      ['infrastructure assets', '🖥️ Infrastructure Assets'],
      ['approvals', '✅ Approvals'],
      ['hr portal', '👥 HR Portal']
    ];

    document.querySelectorAll('button, a').forEach(item => {
      const text = cleanText(item.textContent).toLowerCase();

      mappings.forEach(([match, replacement]) => {
        if (
          text === match ||
          (match !== 'approvals' && text.includes(match))
        ) {
          if (item.dataset.opsaiFinalIcon !== replacement) {
            const badge = item.querySelector('.demo-count-badge, .badge');
            const badgeText = badge?.textContent || '';

            item.textContent = replacement;
            item.dataset.opsaiFinalIcon = replacement;

            if (badge && badgeText) {
              badge.textContent = badgeText;
              item.appendChild(badge);
            }
          }
        }
      });
    });
  }

  function applyEnhancements() {
    ensureConsistentIcons();
    createThinkingIndicator();
    attachComposerEvents();

    const card = findWelcomeCard();
    if (!card) return;

    card.classList.add('opsai-welcome-card');
    createExtraPrompts(card);
    createFeatureCards(card);
    createStatusStrip(card);
  }

  function queueApply() {
    if (queued) return;
    queued = true;

    window.setTimeout(() => {
      queued = false;

      if (observer) observer.disconnect();

      try {
        applyEnhancements();
      } finally {
        if (observer) {
          observer.observe(document.body, {
            childList: true,
            subtree: true
          });
        }
      }
    }, 130);
  }

  function start() {
    applyEnhancements();

    observer = new MutationObserver(queueApply);
    observer.observe(document.body, {
      childList: true,
      subtree: true
    });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', start, { once: true });
  } else {
    start();
  }

  window.addEventListener('load', queueApply, { once: true });
})();
JSEOF

python3 - <<'PY'
from pathlib import Path
import re
import time

index_file = Path.home() / "opsai-assistant-aws" / "app" / "web" / "index.html"
content = index_file.read_text(encoding="utf-8")
version = str(int(time.time()))

content = re.sub(
    r'\s*<link[^>]+href=["\'][^"\']*opsai-ui-enhancements\.css[^"\']*["\'][^>]*>\s*',
    '\n',
    content,
    flags=re.IGNORECASE
)

content = re.sub(
    r'\s*<script[^>]+src=["\'][^"\']*opsai-ui-enhancements\.js[^"\']*["\'][^>]*>\s*</script>\s*',
    '\n',
    content,
    flags=re.IGNORECASE
)

css_tag = f'  <link rel="stylesheet" href="opsai-ui-enhancements.css?v={version}">'
js_tag = f'  <script src="opsai-ui-enhancements.js?v={version}"></script>'

if "</head>" not in content or "</body>" not in content:
    raise SystemExit("ERROR: index.html is missing </head> or </body>.")

content = content.replace("</head>", f"{css_tag}\n</head>", 1)
content = content.replace("</body>", f"{js_tag}\n</body>", 1)

index_file.write_text(content, encoding="utf-8")
print(f"Enhancement references added with version {version}.")
PY

node --check "$WEB_DIR/opsai-ui-enhancements.js"

grep -q "opsai-feature-grid" "$WEB_DIR/opsai-ui-enhancements.css"
grep -q "opsai-status-strip" "$WEB_DIR/opsai-ui-enhancements.css"
grep -q "OpsAI is thinking" "$WEB_DIR/opsai-ui-enhancements.js"
grep -q "Show internal cloud and DevOps job openings" "$WEB_DIR/opsai-ui-enhancements.js"
grep -q "Find DevOps candidates" "$WEB_DIR/opsai-ui-enhancements.js"
grep -q "opsai-ui-enhancements.css" "$WEB_DIR/index.html"
grep -q "opsai-ui-enhancements.js" "$WEB_DIR/index.html"

echo "Final home-screen enhancements validated."

rm -f "$PROJECT_DIR/app/opsai-assistant-ui.zip"

(
  cd "$WEB_DIR"
  zip -qr ../opsai-assistant-ui.zip .
)

DEPLOYMENT_OUTPUT="$(aws amplify create-deployment \
  --app-id "$AMPLIFY_APP_ID" \
  --branch-name "$AMPLIFY_BRANCH_NAME" \
  --region "$AWS_REGION" \
  --output json)"

JOB_ID="$(echo "$DEPLOYMENT_OUTPUT" | python3 -c \
  'import json,sys; print(json.load(sys.stdin)["jobId"])')"

UPLOAD_URL="$(echo "$DEPLOYMENT_OUTPUT" | python3 -c \
  'import json,sys; print(json.load(sys.stdin)["zipUploadUrl"])')"

echo "Amplify deployment job: $JOB_ID"

curl -sS \
  --upload-file "$PROJECT_DIR/app/opsai-assistant-ui.zip" \
  "$UPLOAD_URL"

aws amplify start-deployment \
  --app-id "$AMPLIFY_APP_ID" \
  --branch-name "$AMPLIFY_BRANCH_NAME" \
  --job-id "$JOB_ID" \
  --region "$AWS_REGION" \
  >/dev/null

while true; do
  STATUS="$(aws amplify get-job \
    --app-id "$AMPLIFY_APP_ID" \
    --branch-name "$AMPLIFY_BRANCH_NAME" \
    --job-id "$JOB_ID" \
    --region "$AWS_REGION" \
    --query 'job.summary.status' \
    --output text)"

  echo "Deployment status: $STATUS"

  case "$STATUS" in
    SUCCEED)
      break
      ;;
    FAILED|CANCELLED)
      echo "ERROR: Amplify deployment failed."
      exit 1
      ;;
    *)
      sleep 10
      ;;
  esac
done

echo
echo "========================================================"
echo "Final OpsAI home-screen enhancements deployed."
echo "========================================================"
echo
echo "URL: $AMPLIFY_URL"
echo
echo "Open in Incognito or press Ctrl + Shift + R."
