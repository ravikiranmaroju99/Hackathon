#!/usr/bin/env bash
set -Eeuo pipefail
export AWS_PAGER=""

PROJECT_DIR="$HOME/opsai-assistant-aws"
WEB_DIR="$PROJECT_DIR/app/web"
ENV_FILE="$PROJECT_DIR/.env"

cd "$PROJECT_DIR"

if [[ ! -f "$ENV_FILE" ]]; then
  echo "ERROR: $ENV_FILE was not found."
  exit 1
fi

set -a
source "$ENV_FILE"
set +a

AWS_REGION="${AWS_REGION:-us-east-1}"
AMPLIFY_BRANCH_NAME="${AMPLIFY_BRANCH_NAME:-main}"

if [[ ! -f "$WEB_DIR/opsai-theme-final.js" ]]; then
  echo "ERROR: $WEB_DIR/opsai-theme-final.js was not found."
  exit 1
fi

if [[ ! -f "$WEB_DIR/opsai-theme-final.css" ]]; then
  echo "ERROR: $WEB_DIR/opsai-theme-final.css was not found."
  exit 1
fi

if [[ ! -f "$WEB_DIR/index.html" ]]; then
  echo "ERROR: $WEB_DIR/index.html was not found."
  exit 1
fi

if [[ -z "${AMPLIFY_APP_ID:-}" ]]; then
  AMPLIFY_APP_ID="$(aws amplify list-apps \
    --region "$AWS_REGION" \
    --query "apps[?name=='opsai-assistant-ui'].appId | [0]" \
    --output text)"
fi

if [[ -z "$AMPLIFY_APP_ID" || "$AMPLIFY_APP_ID" == "None" ]]; then
  echo "ERROR: Unable to find the Amplify app ID."
  exit 1
fi

DEFAULT_DOMAIN="$(aws amplify get-app \
  --app-id "$AMPLIFY_APP_ID" \
  --region "$AWS_REGION" \
  --query 'app.defaultDomain' \
  --output text)"

AMPLIFY_URL="${AMPLIFY_URL:-https://${AMPLIFY_BRANCH_NAME}.${DEFAULT_DOMAIN}}"

BACKUP_TIME="$(date +%Y%m%d-%H%M%S)"
BACKUP_DIR="$PROJECT_DIR/backups/ui-stability-$BACKUP_TIME"
mkdir -p "$BACKUP_DIR"

cp "$WEB_DIR/opsai-theme-final.js" "$BACKUP_DIR/opsai-theme-final.js"
cp "$WEB_DIR/opsai-theme-final.css" "$BACKUP_DIR/opsai-theme-final.css"
cp "$WEB_DIR/index.html" "$BACKUP_DIR/index.html"

echo "Backup created: $BACKUP_DIR"

cat > "$WEB_DIR/opsai-theme-final.js" <<'JSEOF'
(() => {
  const ICONS = {
    newChat: '💬',
    infrastructure: '🖥️',
    approvals: '✅',
    hr: '👥'
  };

  let observer;
  let scheduled = false;

  function plainText(value) {
    return String(value || '')
      .replace(/^[^\p{L}\p{N}]+/u, '')
      .replace(/\s+/g, ' ')
      .trim();
  }

  function setStableText(element, icon, label, marker) {
    if (!element) return;

    const expected = `${icon} ${label}`;

    if (element.dataset[marker] === '1' && element.textContent.trim() === expected) {
      return;
    }

    element.textContent = expected;
    element.dataset[marker] = '1';
  }

  function applySidebarIcons() {
    const newChat = document.getElementById('new-chat-button');
    setStableText(newChat, ICONS.newChat, 'New Chat', 'opsaiIconized');

    document.querySelectorAll('button, a').forEach(element => {
      const text = plainText(element.textContent).toLowerCase();

      if (text.includes('infrastructure assets')) {
        setStableText(
          element,
          ICONS.infrastructure,
          'Infrastructure Assets',
          'opsaiIconized'
        );
      } else if (text === 'approvals' || text.startsWith('approvals ')) {
        const badge = element.querySelector('.demo-count-badge, .badge');
        const badgeText = badge ? badge.textContent : '';

        setStableText(
          element,
          ICONS.approvals,
          'Approvals',
          'opsaiIconized'
        );

        if (badge && badgeText) {
          badge.textContent = badgeText;
          element.appendChild(badge);
        }
      } else if (text.includes('hr portal')) {
        setStableText(
          element,
          ICONS.hr,
          'HR Portal',
          'opsaiIconized'
        );
      } else if (text === 'candidate view') {
        setStableText(
          element,
          '👩‍💻',
          'Candidate View',
          'opsaiIconized'
        );
      } else if (text === 'manager view') {
        setStableText(
          element,
          '👨‍💼',
          'Manager View',
          'opsaiIconized'
        );
      }
    });
  }

  function findWelcomeCard() {
    const heading = [...document.querySelectorAll('h1,h2,h3')].find(item =>
      /hello,\s*i am opsai assistant/i.test(item.textContent || '')
    );

    if (!heading) return null;

    let node = heading.parentElement;

    while (node && node !== document.body) {
      const text = node.textContent || '';
      const rect = node.getBoundingClientRect();

      if (
        text.includes('Hello, I am OpsAI Assistant') &&
        text.length < 1200 &&
        rect.width > 280
      ) {
        return node;
      }

      node = node.parentElement;
    }

    return heading.parentElement;
  }

  function enhancePrompt(button) {
    if (!button || button.dataset.opsaiPromptEnhanced === '1') return;

    const original = plainText(button.textContent);
    let icon = '✨';

    if (/node|kubernetes/i.test(original)) icon = '☸️';
    else if (/diskpressure|disk/i.test(original)) icon = '💾';
    else if (/jenkins|pipeline/i.test(original)) icon = '🚀';
    else if (/job|career|hr/i.test(original)) icon = '👥';

    button.textContent = `${icon} ${original}`;
    button.classList.add('opsai-quick-prompt');
    button.dataset.opsaiPromptEnhanced = '1';
  }

  function improveWelcomeCard() {
    const card = findWelcomeCard();
    if (!card) return;

    card.classList.add('opsai-welcome-card');

    if (!card.querySelector('.opsai-hero-visual')) {
      const hero = document.createElement('div');
      hero.className = 'opsai-hero-visual';
      hero.innerHTML = `
        <img
          src="assets/opsai-robot.svg"
          alt="Friendly OpsAI robot assistant"
        >
      `;

      const heading = [...card.querySelectorAll('h1,h2,h3')].find(item =>
        /hello,\s*i am opsai assistant/i.test(item.textContent || '')
      );

      if (heading) card.insertBefore(hero, heading);
      else card.prepend(hero);
    }

    const subtitle = [...card.querySelectorAll('p')].find(item =>
      /kubernetes|rke2|jenkins|cloud|infrastructure/i.test(item.textContent || '')
    );

    if (subtitle && subtitle.dataset.opsaiSubtitleEnhanced !== '1') {
      subtitle.textContent =
        'Your intelligent assistant for Kubernetes, RKE2, Jenkins, cloud, infrastructure and internal opportunities.';
      subtitle.dataset.opsaiSubtitleEnhanced = '1';
    }

    card.querySelectorAll('button').forEach(enhancePrompt);
  }

  function addHeaderBadge() {
    const heading = document.querySelector('.top-header h2');
    if (!heading || heading.querySelector('.opsai-header-badge')) return;

    const badge = document.createElement('span');
    badge.className = 'opsai-header-badge';
    badge.textContent = '✨ AI-powered operations';
    heading.appendChild(badge);
  }

  function addAmbientOrb() {
    if (document.querySelector('.opsai-ai-orb')) return;

    const orb = document.createElement('img');
    orb.className = 'opsai-ai-orb';
    orb.src = 'assets/opsai-ai-orb.svg';
    orb.alt = '';
    orb.setAttribute('aria-hidden', 'true');
    document.body.appendChild(orb);
  }

  function moduleConfig(title) {
    const text = title.toLowerCase();

    if (text.includes('infrastructure')) {
      return {
        image: 'assets/opsai-infrastructure.svg',
        eyebrow: '🖥️ Infrastructure Operations',
        description:
          'Monitor health, patching, vulnerabilities, reboots and approval-based remediation.'
      };
    }

    if (text.includes('internal hr portal') || text === 'hr portal') {
      return {
        image: 'assets/opsai-hr-team.svg',
        eyebrow: '👥 Internal Talent Marketplace',
        description:
          'Search opportunities, discover internal candidates and manage every hiring stage.'
      };
    }

    if (text.includes('approval')) {
      return {
        image: 'assets/opsai-approvals.svg',
        eyebrow: '✅ Human Approval Workflow',
        description:
          'Review, approve, reject and validate controlled operational actions.'
      };
    }

    return null;
  }

  function addModuleHeroes() {
    document.querySelectorAll('.demo-panel, .hr-panel').forEach(panel => {
      if (panel.classList.contains('demo-hidden')) return;
      if (panel.querySelector(':scope > .opsai-module-hero')) return;

      const heading = panel.querySelector('h1,h2,h3');
      if (!heading) return;

      const title = plainText(heading.textContent);
      const config = moduleConfig(title);
      if (!config) return;

      const hero = document.createElement('div');
      hero.className = 'opsai-module-hero';
      hero.innerHTML = `
        <div>
          <div class="opsai-header-badge">${config.eyebrow}</div>
          <h2>${title}</h2>
          <p>${config.description}</p>
        </div>
        <img src="${config.image}" alt="">
      `;

      panel.prepend(hero);
    });
  }

  function iconForHeading(text) {
    if (/current opportunities|open requisitions/i.test(text)) return '💼';
    if (/candidate pool|candidate applications/i.test(text)) return '🧑‍💻';
    if (/hiring managers|projects/i.test(text)) return '👨‍💼';
    if (/application/i.test(text)) return '📄';
    if (/worker|asset|infrastructure/i.test(text)) return '🖥️';
    if (/approval/i.test(text)) return '✅';
    return '';
  }

  function improveSectionHeadings() {
    const selector =
      '.hr-section h3, .demo-panel h2, .demo-panel h3';

    document.querySelectorAll(selector).forEach(heading => {
      const clean = plainText(heading.textContent);
      const icon = iconForHeading(clean);

      if (!icon) return;

      const expected = `${icon} ${clean}`;

      if (
        heading.dataset.opsaiHeadingEnhanced === '1' &&
        heading.textContent.trim() === expected
      ) {
        return;
      }

      heading.textContent = expected;
      heading.dataset.opsaiHeadingEnhanced = '1';
    });
  }

  function addAssistantAvatars() {
    const selector = [
      '[data-role="assistant"]',
      '.assistant-message',
      '.message.assistant',
      '[class*="assistant-message"]'
    ].join(',');

    document.querySelectorAll(selector).forEach(message => {
      if (message.querySelector('.opsai-message-avatar')) return;

      const avatar = document.createElement('img');
      avatar.className = 'opsai-message-avatar';
      avatar.src = 'assets/opsai-robot.svg';
      avatar.alt = 'OpsAI';
      message.prepend(avatar);
    });
  }

  function applyAll() {
    applySidebarIcons();
    improveWelcomeCard();
    addHeaderBadge();
    addAmbientOrb();
    addModuleHeroes();
    improveSectionHeadings();
    addAssistantAvatars();
  }

  function scheduleApply() {
    if (scheduled) return;
    scheduled = true;

    window.setTimeout(() => {
      scheduled = false;

      if (observer) observer.disconnect();

      try {
        applyAll();
      } finally {
        if (observer) {
          observer.observe(document.body, {
            childList: true,
            subtree: true
          });
        }
      }
    }, 120);
  }

  function start() {
    applyAll();

    observer = new MutationObserver(scheduleApply);
    observer.observe(document.body, {
      childList: true,
      subtree: true
    });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', start, { once: true });
  } else {
    start();
  }

  window.addEventListener('load', scheduleApply, { once: true });
})();
JSEOF

cat >> "$WEB_DIR/opsai-theme-final.css" <<'CSSEOF'

/* OpsAI UI stability fix */

.hr-panel,
.demo-panel,
.hr-table-wrap,
.opsai-welcome-card {
  overflow-anchor: none;
}

.opsai-quick-prompt {
  display: block !important;
  width: 100% !important;
  min-height: 48px !important;
  padding: 13px 16px !important;
  text-align: left !important;
  white-space: normal !important;
  line-height: 1.35 !important;
  overflow-wrap: anywhere !important;
}

.opsai-quick-prompt > * {
  display: inline !important;
}

.hr-section h3,
.demo-panel h2,
.demo-panel h3 {
  overflow-wrap: anywhere;
}

.opsai-message-avatar {
  width: 34px;
  height: 34px;
  margin-right: 8px;
  border-radius: 50%;
  object-fit: cover;
  vertical-align: top;
}

.hr-candidate-table .hr-action-column {
  contain: paint;
}

@media (prefers-reduced-motion: reduce) {
  .opsai-hero-visual img,
  .opsai-ai-orb {
    animation: none !important;
  }
}
CSSEOF

python3 - <<'PY'
from pathlib import Path
import re
import time

index_file = Path.home() / "opsai-assistant-aws" / "app" / "web" / "index.html"
content = index_file.read_text(encoding="utf-8")
version = str(int(time.time()))

content = re.sub(
    r'href="opsai-theme-final\.css(?:\?v=[^"]*)?"',
    f'href="opsai-theme-final.css?v={version}"',
    content
)

content = re.sub(
    r'src="opsai-theme-final\.js(?:\?v=[^"]*)?"',
    f'src="opsai-theme-final.js?v={version}"',
    content
)

index_file.write_text(content, encoding="utf-8")
print(f"Cache version updated to {version}.")
PY

node --check "$WEB_DIR/opsai-theme-final.js"

grep -q "opsaiHeadingEnhanced" "$WEB_DIR/opsai-theme-final.js"
grep -q "opsaiPromptEnhanced" "$WEB_DIR/opsai-theme-final.js"
grep -q "observer.disconnect" "$WEB_DIR/opsai-theme-final.js"
grep -q "overflow-anchor" "$WEB_DIR/opsai-theme-final.css"

echo "UI stability validation passed."

rm -f "$PROJECT_DIR/app/opsai-assistant-ui.zip"

(
  cd "$WEB_DIR"
  zip -qr ../opsai-assistant-ui.zip .
)

DEPLOYMENT_OUTPUT="$(aws amplify create-deployment \
  --app-id "$AMPLIFY_APP_ID" \
  --branch-name "$AMPLIFY_BRANCH_NAME" \
  --region "$AWS_REGION" \
  --output json)"

JOB_ID="$(echo "$DEPLOYMENT_OUTPUT" | python3 -c \
  'import json,sys; print(json.load(sys.stdin)["jobId"])')"

UPLOAD_URL="$(echo "$DEPLOYMENT_OUTPUT" | python3 -c \
  'import json,sys; print(json.load(sys.stdin)["zipUploadUrl"])')"

echo "Amplify deployment job: $JOB_ID"

curl -sS \
  --upload-file "$PROJECT_DIR/app/opsai-assistant-ui.zip" \
  "$UPLOAD_URL"

aws amplify start-deployment \
  --app-id "$AMPLIFY_APP_ID" \
  --branch-name "$AMPLIFY_BRANCH_NAME" \
  --job-id "$JOB_ID" \
  --region "$AWS_REGION" \
  >/dev/null

while true; do
  STATUS="$(aws amplify get-job \
    --app-id "$AMPLIFY_APP_ID" \
    --branch-name "$AMPLIFY_BRANCH_NAME" \
    --job-id "$JOB_ID" \
    --region "$AWS_REGION" \
    --query 'job.summary.status' \
    --output text)"

  echo "Deployment status: $STATUS"

  case "$STATUS" in
    SUCCEED)
      break
      ;;
    FAILED|CANCELLED)
      echo "ERROR: Amplify deployment failed."
      exit 1
      ;;
    *)
      sleep 10
      ;;
  esac
done

echo
echo "========================================================"
echo "OpsAI moving-data and repeated-icon issue fixed."
echo "========================================================"
echo
echo "URL: $AMPLIFY_URL"
echo
echo "Open in Incognito or press Ctrl + Shift + R."
